@echo off
title Tarab - 7iyd mn PC
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-CimInstance Win32_Process -Filter \"Name like 'python%%'\" | Where-Object { $_.CommandLine -like '*tarab_worker.py*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }; Remove-Item (Join-Path ([Environment]::GetFolderPath('Startup')) 'Tarab.lnk') -ErrorAction SilentlyContinue; Remove-Item (Join-Path $env:LOCALAPPDATA 'TarabWorker') -Recurse -Force -ErrorAction SilentlyContinue"
echo Tarab t7iyd mn PC. Lmusic dyalk mazal f l'app.
pause
