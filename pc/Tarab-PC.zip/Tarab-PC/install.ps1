# Tarab - installation dyal PC (Windows 10/11)
$ErrorActionPreference = "Continue"
$ProgressPreference = "SilentlyContinue"
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$Dir = Join-Path $env:LOCALAPPDATA "TarabWorker"
$SupaUrl = "https://faafhcbjprtsvyximbtm.supabase.co"
$SupaKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZhYWZoY2JqcHJ0c3Z5eGltYnRtIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTM1NDQ1ODAsImV4cCI6MjEwOTEyMDU4MH0.pSPeeY5Iai6DIeGQjcpHhThS7DNNUB-6GoiUpjoTyBg"

function Say($t, $c = "White") { Write-Host $t -ForegroundColor $c }
function Step($n, $t) { Write-Host ""; Write-Host "[$n/6] $t" -ForegroundColor Yellow }
function Has($cmd) { return [bool](Get-Command $cmd -ErrorAction SilentlyContinue) }
function Refresh-Path {
  $m = [Environment]::GetEnvironmentVariable("Path", "Machine")
  $u = [Environment]::GetEnvironmentVariable("Path", "User")
  $env:Path = "$m;$u;$env:LOCALAPPDATA\Microsoft\WinGet\Links"
}
function Winget-Install($id) {
  if (-not (Has "winget")) { throw "winget ma kaynch. Update Windows (App Installer mn Microsoft Store) o 3awed." }
  winget install -e --id $id --silent --accept-package-agreements --accept-source-agreements | Out-Host
}

Clear-Host
Say "  _____               _    " Yellow
Say " |_   _|_ _ _ __ __ _| |__ " Yellow
Say "   | |/ _' | '__/ _' | '_ \" Yellow
Say "   | | (_| | | | (_| | |_) |" Yellow
Say "   |_|\__,_|_|  \__,_|_.__/   PC" Yellow
Say ""
Say "Had script ghaywjjed PC bach y7mel lmusic dyalk. Ghaywali kaykhdem bou7do mli t3all9 PC."

# ---------- 1. Python ----------
Step 1 "Python"
function Find-Python {
  foreach ($c in @("py", "python")) {
    $cmd = Get-Command $c -ErrorAction SilentlyContinue
    if ($cmd -and $cmd.Source -notlike "*WindowsApps*") {
      try {
        $exe = & $c -3 -c "import sys; print(sys.executable)" 2>$null
        if (-not $exe) { $exe = & $c -c "import sys; print(sys.executable)" 2>$null }
        if ($exe -and (Test-Path $exe)) { return $exe.Trim() }
      } catch {}
    }
  }
  foreach ($v in @("313", "312", "311", "310")) {
    $p = Join-Path $env:LOCALAPPDATA "Programs\Python\Python$v\python.exe"
    if (Test-Path $p) { return $p }
  }
  return $null
}
$Py = Find-Python
if (-not $Py) {
  Say "Python ma kaynch, kanzid Python 3.12..."
  Winget-Install "Python.Python.3.12"
  Refresh-Path
  $Py = Find-Python
}
if (-not $Py) { throw "Ma tinstallach Python. Installih mn python.org (cochi 'Add to PATH') o 3awed." }
$PyW = Join-Path (Split-Path $Py) "pythonw.exe"
Say "OK: $Py" Green

# ---------- 2. Python packages ----------
Step 2 "yt-dlp + packages"
& $Py -m pip install --upgrade --quiet pip 2>$null
& $Py -m pip install --upgrade --quiet "yt-dlp[default]" requests pillow
if ($LASTEXITCODE -ne 0) { throw "pip install ma khdamch" }
Say "OK" Green

# ---------- 3. ffmpeg + deno ----------
Step 3 "ffmpeg (jawda) + deno (YouTube)"
Refresh-Path
if (-not (Has "ffmpeg")) { Say "Kanzid ffmpeg..."; Winget-Install "Gyan.FFmpeg" }
if (-not (Has "deno")) { Say "Kanzid deno..."; Winget-Install "DenoLand.Deno" }
Refresh-Path
if (Has "ffmpeg") { Say "ffmpeg OK" Green } else { Say "ffmpeg mazal ma bancch (ghaybaan mn ba3d restart)" DarkYellow }
if (Has "deno") { Say "deno OK" Green } else { Say "deno mazal ma bancch (ghaybaan mn ba3d restart)" DarkYellow }

# ---------- 4. files ----------
Step 4 "Copie dyal script"
Get-CimInstance Win32_Process -Filter "Name like 'python%'" -ErrorAction SilentlyContinue |
  Where-Object { $_.CommandLine -like "*tarab_worker.py*" } |
  ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
New-Item -ItemType Directory -Force -Path $Dir | Out-Null
Copy-Item (Join-Path $Here "tarab_worker.py") (Join-Path $Dir "tarab_worker.py") -Force
Copy-Item (Join-Path $Here "uninstall.bat") (Join-Path $Dir "uninstall.bat") -Force -ErrorAction SilentlyContinue
Say "OK: $Dir" Green

# ---------- 5. account ----------
Step 5 "Compte Tarab (nefs email o mot de passe dyal l'app)"
$Cfg = Join-Path $Dir "config.json"
$ok = $false
if (Test-Path $Cfg) {
  $r = & $Py (Join-Path $Dir "tarab_worker.py") --test-login 2>&1
  if ("$r" -like "OK*") { $ok = $true; Say "Compte deja m9ad" Green }
}
while (-not $ok) {
  $email = Read-Host "Email"
  $sec = Read-Host "Mot de passe" -AsSecureString
  $pass = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec))
  $cfgObj = @{ url = $SupaUrl; key = $SupaKey; email = $email.Trim(); password = $pass }
  $json = $cfgObj | ConvertTo-Json
  [IO.File]::WriteAllText($Cfg, $json, (New-Object System.Text.UTF8Encoding $false))
  $r = & $Py (Join-Path $Dir "tarab_worker.py") --test-login 2>&1
  if ("$r" -like "OK*") { $ok = $true; Say "Dkhalt mzyan" Green }
  else { Say "Email wla mot de passe ghalet. 3awed." Red }
}

# ---------- 6. auto start ----------
Step 6 "Ybda bou7do m3a Windows"
$Startup = [Environment]::GetFolderPath("Startup")
$Lnk = Join-Path $Startup "Tarab.lnk"
$W = New-Object -ComObject WScript.Shell
$S = $W.CreateShortcut($Lnk)
$S.TargetPath = $PyW
$S.Arguments = '"' + (Join-Path $Dir "tarab_worker.py") + '"'
$S.WorkingDirectory = $Dir
$S.WindowStyle = 7
$S.Description = "Tarab music downloader"
$S.Save()
Start-Process -FilePath $PyW -ArgumentList ('"' + (Join-Path $Dir "tarab_worker.py") + '"') -WorkingDirectory $Dir -WindowStyle Hidden
Start-Sleep -Seconds 4
Say "OK" Green

Say ""
Say "=============================================" Green
Say " Safi! Tarab khdam f PC." Green
Say " Daba 7el l'app f iPhone -> Zid: ghatchof 'PC m3all9'." Green
Say " Ghaybda bou7do kol mra t3all9 PC." Green
Say "=============================================" Green
Say ""
Say "Log: $Dir\tarab.log" DarkGray
