@echo off
title Tarab - installation
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
if errorlevel 1 (
  echo.
  echo Wa9e3 mochkil. Sowwer had l'ecran o sifto l Claude.
)
echo.
pause
